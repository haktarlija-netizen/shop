import React from 'react'

import Bonsho from './bonshofarax'
export default function page() {
  return (
<>
<Bonsho />

</>
  )
}
