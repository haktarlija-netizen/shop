import React from 'react'
import NikahStepForm from './nikahForm'

export default function page() {
  return (
    <>
    <NikahStepForm />
    
    </>
  )
}
