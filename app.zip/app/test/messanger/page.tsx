import React from 'react'

import Messangers from '../Messanger'
export default function pages() {
  return (
<>



<Messangers />



</>

  )
}
