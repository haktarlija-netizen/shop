import React from 'react'
import Spiner from './myface'
import Spiner3 from './TopNav'

export default function pages() {
  return (
<>





<Spiner />

</>

  )
}
