import React from 'react'

import Snackes from './Home'

export default function page() {
  return (
 <Snackes  />
  )
}


