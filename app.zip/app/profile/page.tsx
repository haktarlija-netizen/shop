import React from 'react'
import Home from './Home'
import HBoutm from './buttomnavbar/page'





function page() {
  return (
<>

<Home />
<HBoutm />

</>
  )
}

export default page